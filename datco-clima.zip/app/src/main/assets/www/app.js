'use strict';
/* DATCO Clima — Open-Meteo + Windy */

const $ = s => document.querySelector(s);
const DEFAULT_PLACE = { name: 'Buenos Aires', sub: 'Argentina', lat: -34.6037, lon: -58.3816, mine: false };
const CARD = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];

const state = { place: null, data: null, aq: null, ts: 0, layer: 'radar', tab: 'weather' };

/* ---------- utilidades ---------- */
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const cardinal = d => CARD[Math.round(((d % 360) + 360) % 360 / 45) % 8];
const r = n => Math.round(n);
const ls = {
  get(k, def) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};

let toastTimer;
function toast(msg, ms = 2600) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), ms);
}

async function getJSON(url, ms = 15000) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try {
    const res = await fetch(url, { signal: c.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally { clearTimeout(t); }
}

function info(code, day = 1) {
  if (code === 0) return { e: day ? '☀️' : '🌙', t: 'Despejado', k: 'clear' };
  if (code === 1) return { e: day ? '🌤️' : '🌙', t: 'Mayormente despejado', k: 'clear' };
  if (code === 2) return { e: day ? '⛅' : '☁️', t: 'Parcialmente nublado', k: 'cloudy' };
  if (code === 3) return { e: '☁️', t: 'Nublado', k: 'cloudy' };
  if (code === 45 || code === 48) return { e: '🌫️', t: 'Niebla', k: 'fog' };
  if (code >= 51 && code <= 57) return { e: '🌦️', t: 'Llovizna', k: 'rain' };
  if (code >= 61 && code <= 67) return { e: '🌧️', t: 'Lluvia', k: 'rain' };
  if (code >= 71 && code <= 77) return { e: '🌨️', t: 'Nieve', k: 'snow' };
  if (code >= 80 && code <= 82) return { e: '🌧️', t: 'Chubascos', k: 'rain' };
  if (code === 85 || code === 86) return { e: '🌨️', t: 'Nevadas', k: 'snow' };
  if (code >= 95) return { e: '⛈️', t: 'Tormenta', k: 'storm' };
  return { e: '☁️', t: 'Nublado', k: 'cloudy' };
}

/* ---------- fondo animado ---------- */
function buildSky() {
  let s = '';
  for (let i = 0; i < 45; i++) {
    const sz = 1 + Math.random() * 2.5;
    s += `<i class="star" style="left:${Math.random() * 100}%;top:${Math.random() * 60}%;width:${sz}px;height:${sz}px;animation-delay:${(Math.random() * 3).toFixed(2)}s"></i>`;
  }
  $('#stars').innerHTML = s;
  let d = '';
  for (let i = 0; i < 70; i++) {
    d += `<i class="drop" style="left:${Math.random() * 100}%;animation-duration:${(0.55 + Math.random() * 0.5).toFixed(2)}s;animation-delay:${(-Math.random() * 2).toFixed(2)}s"></i>`;
  }
  $('#drops').innerHTML = d;
  let f = '';
  for (let i = 0; i < 40; i++) {
    f += `<i class="flake" style="left:${Math.random() * 100}%;animation-duration:${(6 + Math.random() * 6).toFixed(1)}s;animation-delay:${(-Math.random() * 8).toFixed(1)}s"></i>`;
  }
  $('#flakes').innerHTML = f;
}

function setSky(kind, day) {
  $('#sky').className = (day ? 'day ' : 'night ') + kind;
  document.querySelector('meta[name=theme-color]').setAttribute('content', day ? '#2f8ee8' : '#0b1437');
}

/* ---------- datos ---------- */
function wxUrl(lat, lon) {
  const cur = 'temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m';
  const hr = 'temperature_2m,apparent_temperature,relative_humidity_2m,precipitation_probability,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,is_day,visibility,uv_index';
  const dy = 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,sunrise,sunset,uv_index_max';
  return `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=${cur}&hourly=${hr}&daily=${dy}&minutely_15=precipitation&forecast_minutely_15=24&past_minutely_15=0&timezone=auto&forecast_days=7`;
}

async function fetchAll(place) {
  const data = await getJSON(wxUrl(place.lat, place.lon));
  let aq = null;
  try {
    aq = await getJSON(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${place.lat}&longitude=${place.lon}&current=us_aqi,pm2_5&timezone=auto`, 8000);
  } catch (e) {}
  return { data, aq };
}

function nowIdx(d) {
  const t = d.current.time.slice(0, 13) + ':00';
  const i = d.hourly.time.indexOf(t);
  return i < 0 ? 0 : i;
}

/* ---------- render ---------- */
function hourCard(d, i, label, useCur) {
  const h = d.hourly, c = d.current;
  const day = useCur ? c.is_day : h.is_day[i];
  const code = useCur ? c.weather_code : h.weather_code[i];
  const t = useCur ? c.temperature_2m : h.temperature_2m[i];
  const f = useCur ? c.apparent_temperature : h.apparent_temperature[i];
  const hu = useCur ? c.relative_humidity_2m : h.relative_humidity_2m[i];
  const w = useCur ? c.wind_speed_10m : h.wind_speed_10m[i];
  const dir = useCur ? c.wind_direction_10m : h.wind_direction_10m[i];
  const p = useCur ? c.pressure_msl : h.pressure_msl[i];
  const pr = h.precipitation_probability[i];
  return `<div class="hc">
    <div class="hl">${label}</div>
    <div class="he">${info(code, day).e}</div>
    <div class="ht">${r(t)}°</div>
    <div class="row"><span>🌡️</span><b>${r(f)}°</b></div>
    <div class="row"><span>💧</span><b>${r(hu)}%</b></div>
    <div class="row"><span>☔</span><b>${pr == null ? '--' : r(pr)}%</b></div>
    <div class="row"><span>💨</span><b>${r(w)} km/h</b></div>
    <div class="row"><span>🧭</span><b>${cardinal(dir)}<span class="arr" style="transform:rotate(${r(dir + 180)}deg)">↑</span></b></div>
    <div class="row"><span>⏲️</span><b>${r(p)} hPa</b></div>
  </div>`;
}

function renderHourly(d) {
  const i0 = nowIdx(d);
  let html = hourCard(d, i0, 'Ahora', true);
  for (let i = i0 + 1; i <= i0 + 24 && i < d.hourly.time.length; i++) {
    html += hourCard(d, i, d.hourly.time[i].slice(11, 16), false);
  }
  $('#hourly').innerHTML = html;
  $('#hourly').scrollLeft = 0;
}

function renderDetails(d, aq) {
  const c = d.current, dl = d.daily, i0 = nowIdx(d);
  const vis = d.hourly.visibility[i0];
  const uv = dl.uv_index_max[0];
  const uvTxt = uv == null ? '--' : (uv < 3 ? 'Bajo' : uv < 6 ? 'Moderado' : uv < 8 ? 'Alto' : uv < 11 ? 'Muy alto' : 'Extremo') + ' (' + r(uv) + ')';
  let aqTxt = '--';
  if (aq && aq.current && aq.current.us_aqi != null) {
    const a = aq.current.us_aqi;
    aqTxt = (a <= 50 ? 'Buena' : a <= 100 ? 'Moderada' : a <= 150 ? 'Regular' : a <= 200 ? 'Mala' : a <= 300 ? 'Muy mala' : 'Peligrosa') + ' (' + r(a) + ')';
  }
  const items = [
    ['🌅 Amanecer', dl.sunrise[0].slice(11, 16)],
    ['🌇 Atardecer', dl.sunset[0].slice(11, 16)],
    ['☀️ Índice UV', uvTxt],
    ['🍃 Calidad del aire', aqTxt],
    ['👁️ Visibilidad', vis == null ? '--' : (vis / 1000 >= 10 ? '+10' : (vis / 1000).toFixed(1)) + ' km'],
    ['💨 Ráfagas', r(c.wind_gusts_10m) + ' km/h'],
    ['⏲️ Presión', r(c.pressure_msl) + ' hPa'],
    ['🌧️ Lluvia hoy', (dl.precipitation_sum[0] || 0).toFixed(1) + ' mm']
  ];
  $('#details').innerHTML = items.map(x => `<div class="dt"><small>${x[0]}</small><b>${x[1]}</b></div>`).join('');
}

function renderRainAlert(d) {
  const box = $('#rainAlert');
  const c = d.current, m = d.minutely_15;
  let txt = '✅ Sin lluvia prevista en las próximas 2 horas', wet = false;
  if (c.precipitation >= 0.1) {
    txt = '🌧️ Está lloviendo ahora'; wet = true;
  } else if (m && m.time) {
    let start = m.time.findIndex(t => t >= c.time);
    if (start < 0) start = 0;
    for (let k = 0; k < 8 && start + k < m.time.length; k++) {
      if ((m.precipitation[start + k] || 0) >= 0.1) {
        txt = k === 0 ? '🌧️ Empieza a llover ahora' : `🌧️ Lluvia estimada en ~${k * 15} min`;
        wet = true; break;
      }
    }
  }
  box.textContent = txt;
  box.className = 'alert' + (wet ? ' wet' : '');
}

function renderDaily(d) {
  const dl = d.daily;
  const mn = Math.min(...dl.temperature_2m_min), mx = Math.max(...dl.temperature_2m_max);
  const span = (mx - mn) || 1;
  $('#daily').innerHTML = dl.time.map((dt, i) => {
    const [Y, M, D] = dt.split('-').map(Number);
    const o = new Date(Y, M - 1, D);
    const name = i === 0 ? 'Hoy' : i === 1 ? 'Mañana' : o.toLocaleDateString('es-AR', { weekday: 'long' });
    const small = o.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' });
    const left = ((dl.temperature_2m_min[i] - mn) / span) * 100;
    const width = Math.max(10, ((dl.temperature_2m_max[i] - dl.temperature_2m_min[i]) / span) * 100);
    return `<div class="day" data-i="${i}">
      <div class="dayhead">
        <div class="dn">${name}<small>${small}</small></div>
        <div class="de">${info(dl.weather_code[i], 1).e}</div>
        <div class="dr">💧 ${dl.precipitation_probability_max[i] == null ? '--' : r(dl.precipitation_probability_max[i])}%</div>
        <div class="dmin">${r(dl.temperature_2m_min[i])}°</div>
        <div class="bar"><i style="left:${left}%;width:${Math.min(width, 100 - left)}%"></i></div>
        <div class="dmax">${r(dl.temperature_2m_max[i])}°</div>
        <div class="chev">▾</div>
      </div>
      <div class="dayhours"></div>
    </div>`;
  }).join('');
}

function buildDayHours(i) {
  const d = state.data, h = d.hourly;
  const dt = d.daily.time[i];
  const i0 = nowIdx(d);
  let html = '';
  for (let k = 0; k < h.time.length; k++) {
    if (!h.time[k].startsWith(dt)) continue;
    if (i === 0 && k < i0) continue;
    html += hourCard(d, k, h.time[k].slice(11, 16), false);
  }
  return `<div class="hscroll">${html}</div>`;
}

$('#daily').addEventListener('click', e => {
  const head = e.target.closest('.dayhead');
  if (!head || !state.data) return;
  const day = head.parentElement;
  const open = day.classList.contains('open');
  document.querySelectorAll('#daily .day.open').forEach(x => x.classList.remove('open'));
  if (!open) {
    const box = day.querySelector('.dayhours');
    if (!box.innerHTML) box.innerHTML = buildDayHours(Number(day.dataset.i));
    day.classList.add('open');
    setTimeout(() => day.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 60);
  }
});

function render() {
  const { place, data: d, aq } = state;
  if (!d) return;
  const c = d.current, inf = info(c.weather_code, c.is_day);
  $('#city').textContent = place.mine ? 'Mi ubicación' : place.name;
  $('#sub').textContent = place.sub || '';
  const [Y, M, D] = c.time.slice(0, 10).split('-').map(Number);
  $('#date').textContent = new Date(Y, M - 1, D).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });
  $('#temp').textContent = r(c.temperature_2m) + '°';
  $('#cond').textContent = inf.e + ' ' + inf.t;
  $('#hilo').textContent = `Máx ${r(d.daily.temperature_2m_max[0])}° · Mín ${r(d.daily.temperature_2m_min[0])}°`;
  setSky(inf.k, c.is_day);
  renderRainAlert(d);
  renderHourly(d);
  renderDetails(d, aq);
  renderDaily(d);
  renderFavs();
}

/* ---------- favoritas ---------- */
function samePlace(a, b) { return Math.abs(a.lat - b.lat) < 0.01 && Math.abs(a.lon - b.lon) < 0.01; }

function renderFavs() {
  const favs = ls.get('favs', []);
  const p = state.place;
  let html = `<button class="fav ${p.mine ? 'on' : ''}" data-mine="1">📍 Mi ubicación</button>`;
  favs.forEach((f, i) => {
    html += `<button class="fav ${!p.mine && samePlace(f, p) ? 'on' : ''}" data-i="${i}">${f.name}<i data-del="${i}">✕</i></button>`;
  });
  $('#favs').innerHTML = html;
  const btn = $('#btnFav');
  if (p.mine) btn.classList.add('hidden');
  else {
    btn.classList.remove('hidden');
    btn.textContent = favs.some(f => samePlace(f, p)) ? '★ Guardada' : '☆ Guardar ciudad';
  }
}

$('#favs').addEventListener('click', e => {
  const favs = ls.get('favs', []);
  const del = e.target.closest('[data-del]');
  if (del) {
    favs.splice(Number(del.dataset.del), 1);
    ls.set('favs', favs);
    renderFavs();
    return;
  }
  const b = e.target.closest('.fav');
  if (!b) return;
  if (b.dataset.mine) useMyLocation();
  else loadPlace(favs[Number(b.dataset.i)]);
});

$('#btnFav').addEventListener('click', () => {
  const p = state.place;
  if (p.mine) return;
  let favs = ls.get('favs', []);
  if (favs.some(f => samePlace(f, p))) favs = favs.filter(f => !samePlace(f, p));
  else favs.push({ name: p.name, sub: p.sub, lat: p.lat, lon: p.lon, mine: false });
  ls.set('favs', favs);
  renderFavs();
});

/* ---------- carga ---------- */
function notifyNative(p) {
  try {
    if (window.AndroidBridge) {
      AndroidBridge.saveLocation(String(p.lat), String(p.lon), p.mine ? (p.locality || 'Mi ubicación') : p.name);
    }
  } catch (e) {}
}

async function loadPlace(place, silent) {
  state.place = place;
  ls.set('place', place);
  $('#suggest').classList.add('hidden');
  if (!silent) toast('Actualizando…', 1500);
  try {
    const { data, aq } = await fetchAll(place);
    state.data = data; state.aq = aq; state.ts = Date.now();
    ls.set('cache', { place, data, aq, ts: state.ts });
    render();
    notifyNative(place);
    if (state.tab === 'radar') loadRadar(false);
  } catch (e) {
    if (state.data) toast('Sin conexión: mostrando datos guardados');
    else toast('No pude cargar el clima. Revisá tu conexión.');
  }
}

function locate() {
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error('nogeo'));
    navigator.geolocation.getCurrentPosition(
      p => res({ lat: p.coords.latitude, lon: p.coords.longitude }),
      rej, { enableHighAccuracy: false, timeout: 15000, maximumAge: 300000 });
  });
}

async function useMyLocation() {
  toast('Buscando tu ubicación…', 2000);
  try {
    const pos = await locate();
    const place = { name: 'Mi ubicación', lat: pos.lat, lon: pos.lon, mine: true, sub: '' };
    await loadPlace(place, true);
    reverse(place);
  } catch (e) {
    toast('No pude obtener la ubicación. Activá el GPS o buscá una ciudad.');
    if (!state.data) loadPlace(DEFAULT_PLACE, true);
  }
}

async function reverse(place) {
  try {
    const j = await getJSON(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${place.lat}&longitude=${place.lon}&localityLanguage=es`, 8000);
    const loc = j.locality || j.city || '';
    const sub = [loc, j.principalSubdivision].filter(Boolean).join(', ');
    if (state.place && state.place.mine && samePlace(state.place, place)) {
      state.place.sub = sub;
      state.place.locality = loc;
      $('#sub').textContent = sub;
      ls.set('place', state.place);
      notifyNative(state.place);
    }
  } catch (e) {}
}

/* ---------- búsqueda ---------- */
let searchTimer;
async function searchCities(q) {
  const j = await getJSON(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=es&format=json`, 10000);
  return j.results || [];
}

function showSuggest(list) {
  const ul = $('#suggest');
  if (!list.length) {
    ul.innerHTML = '<li>Sin resultados</li>';
    ul.classList.remove('hidden');
    return;
  }
  ul.innerHTML = list.map((x, i) =>
    `<li data-i="${i}">${x.name}<small>${[x.admin1, x.country].filter(Boolean).join(', ')}</small></li>`).join('');
  ul.classList.remove('hidden');
  ul._list = list;
}

function pick(x) {
  $('#q').value = '';
  $('#q').blur();
  loadPlace({ name: x.name, sub: [x.admin1, x.country].filter(Boolean).join(', '), lat: x.latitude, lon: x.longitude, mine: false });
}

$('#q').addEventListener('input', () => {
  clearTimeout(searchTimer);
  const q = $('#q').value.trim();
  if (q.length < 2) { $('#suggest').classList.add('hidden'); return; }
  searchTimer = setTimeout(async () => {
    try { showSuggest(await searchCities(q)); } catch (e) { toast('No pude buscar. Revisá tu conexión.'); }
  }, 350);
});

async function doSearch() {
  const q = $('#q').value.trim();
  if (q.length < 2) { toast('Escribí el nombre de una ciudad'); return; }
  try {
    const l = await searchCities(q);
    if (l.length === 1) pick(l[0]); else showSuggest(l);
  } catch (e) { toast('No pude buscar. Revisá tu conexión.'); }
}

$('#q').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
$('#btnSearch').addEventListener('click', doSearch);
$('#suggest').addEventListener('click', e => {
  const li = e.target.closest('li[data-i]');
  if (li && $('#suggest')._list) pick($('#suggest')._list[Number(li.dataset.i)]);
});
$('#btnLoc').addEventListener('click', useMyLocation);
$('#btnRef').addEventListener('click', () => {
  if (state.place && state.place.mine) useMyLocation(); else if (state.place) loadPlace(state.place);
});

/* ---------- radar (Windy) ---------- */
const LAYERS = [
  ['radar', '🛰️ Radar'], ['rain', '🌧️ Lluvia'], ['wind', '💨 Viento'], ['gust', '🌬️ Ráfagas'],
  ['clouds', '☁️ Nubes'], ['temp', '🌡️ Temperatura'], ['pressure', '⏲️ Presión']
];

function renderLayers() {
  $('#layers').innerHTML = LAYERS.map(l =>
    `<button class="chip ${state.layer === l[0] ? 'on' : ''}" data-l="${l[0]}">${l[1]}</button>`).join('');
}

function radarUrl() {
  const p = state.place || DEFAULT_PLACE;
  const lat = (+p.lat).toFixed(3), lon = (+p.lon).toFixed(3);
  const zoom = (state.layer === 'radar' || state.layer === 'rain') ? 7 : 6;
  return 'https://embed.windy.com/embed2.html?lat=' + lat + '&lon=' + lon +
    '&detailLat=' + lat + '&detailLon=' + lon +
    '&width=650&height=450&zoom=' + zoom + '&level=surface&overlay=' + state.layer +
    '&product=ecmwf&menu=&message=true&marker=true&calendar=now&pressure=&type=map&location=coordinates&detail=' +
    '&metricWind=km%2Fh&metricTemp=%C2%B0C&radarRange=-1';
}

function loadRadar(force) {
  const f = $('#windy');
  const url = radarUrl();
  if (f.dataset.u !== url || force) {
    $('#radarMsg').textContent = 'Cargando radar…';
    $('#radarMsg').classList.remove('hidden');
    f.dataset.u = url;
    f.src = url;
  }
}

$('#windy').addEventListener('load', () => {
  setTimeout(() => $('#radarMsg').classList.add('hidden'), 1200);
});

$('#layers').addEventListener('click', e => {
  const b = e.target.closest('.chip');
  if (!b) return;
  state.layer = b.dataset.l;
  ls.set('layer', state.layer);
  renderLayers();
  loadRadar(false);
});

/* ---------- pestañas ---------- */
function showTab(t) {
  state.tab = t;
  $('#viewWeather').classList.toggle('active', t === 'weather');
  $('#viewRadar').classList.toggle('active', t === 'radar');
  $('#tabW').classList.toggle('active', t === 'weather');
  $('#tabR').classList.toggle('active', t === 'radar');
  if (t === 'radar') loadRadar(false);
}
$('#tabW').addEventListener('click', () => showTab('weather'));
$('#tabR').addEventListener('click', () => showTab('radar'));

window.handleBack = function () {
  if (!$('#suggest').classList.contains('hidden')) { $('#suggest').classList.add('hidden'); return true; }
  if (state.tab === 'radar') { showTab('weather'); return true; }
  const open = document.querySelector('#daily .day.open');
  if (open) { open.classList.remove('open'); return true; }
  return false;
};

/* ---------- arranque ---------- */
function refreshIfStale() {
  if (document.hidden || !state.place) return;
  if (Date.now() - state.ts > 10 * 60 * 1000) {
    if (state.place.mine) useMyLocation(); else loadPlace(state.place, true);
  }
}
document.addEventListener('visibilitychange', refreshIfStale);
setInterval(refreshIfStale, 5 * 60 * 1000);

async function init() {
  buildSky();
  state.layer = ls.get('layer', 'radar');
  renderLayers();

  // splash DATCO
  setTimeout(() => {
    $('#splash').classList.add('out');
    setTimeout(() => $('#splash').remove(), 700);
  }, 2600);

  const cache = ls.get('cache', null);
  if (cache && cache.data && cache.place) {
    state.place = cache.place; state.data = cache.data; state.aq = cache.aq; state.ts = 0;
    try { render(); } catch (e) {}
  }
  const saved = ls.get('place', null);
  if (!saved) {
    await useMyLocation();
  } else if (saved.mine) {
    state.place = saved;
    await useMyLocation();
  } else {
    await loadPlace(saved, true);
  }
}

init();
