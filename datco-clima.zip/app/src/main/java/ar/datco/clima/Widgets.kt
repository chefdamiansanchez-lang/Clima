package ar.datco.clima

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

open class BaseWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetEngine.renderAll(context)
        WidgetEngine.refresh(context, goAsync())
    }

    override fun onEnabled(context: Context) {
        WidgetEngine.renderAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_REFRESH) {
            WidgetEngine.refresh(context, goAsync())
        } else {
            super.onReceive(context, intent)
        }
    }
}

class MiniWidget : BaseWidget()

class ForecastWidget : BaseWidget()
