package ar.datco.clima

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

const val ACTION_REFRESH = "ar.datco.clima.REFRESH"

data class Hour(val label: String, val emoji: String, val temp: Int)

data class Snap(
    val name: String,
    val temp: Int,
    val emoji: String,
    val text: String,
    val max: Int,
    val min: Int,
    val hours: List<Hour>
)

object WidgetEngine {

    private val classes = listOf(MiniWidget::class.java, ForecastWidget::class.java)

    fun refresh(ctx: Context, pending: BroadcastReceiver.PendingResult?) {
        val app = ctx.applicationContext
        thread {
            try {
                val sp = app.getSharedPreferences("wx", Context.MODE_PRIVATE)
                val lat = sp.getString("lat", null)
                val lon = sp.getString("lon", null)
                if (lat != null && lon != null) {
                    val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,weather_code,is_day" +
                        "&hourly=temperature_2m,weather_code,is_day" +
                        "&daily=temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=2"
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000
                    conn.readTimeout = 15000
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    sp.edit().putString("json", body).putLong("ts", System.currentTimeMillis()).apply()
                }
            } catch (e: Exception) {
                // sin conexión: se muestran los datos guardados
            }
            try {
                renderAll(app)
            } catch (e: Exception) {
            }
            pending?.finish()
        }
    }

    fun emoji(code: Int, day: Boolean): String = when {
        code == 0 -> if (day) "☀️" else "🌙"
        code == 1 -> if (day) "🌤️" else "🌙"
        code == 2 -> if (day) "⛅" else "☁️"
        code == 3 -> "☁️"
        code == 45 || code == 48 -> "🌫️"
        code in 51..57 -> "🌦️"
        code in 61..67 -> "🌧️"
        code in 71..77 -> "🌨️"
        code in 80..82 -> "🌧️"
        code == 85 || code == 86 -> "🌨️"
        code >= 95 -> "⛈️"
        else -> "☁️"
    }

    fun text(code: Int): String = when {
        code == 0 -> "Despejado"
        code == 1 -> "Mayormente despejado"
        code == 2 -> "Parcialmente nublado"
        code == 3 -> "Nublado"
        code == 45 || code == 48 -> "Niebla"
        code in 51..57 -> "Llovizna"
        code in 61..67 -> "Lluvia"
        code in 71..77 -> "Nieve"
        code in 80..82 -> "Chubascos"
        code == 85 || code == 86 -> "Nevadas"
        code >= 95 -> "Tormenta"
        else -> "Nublado"
    }

    fun load(ctx: Context): Snap? {
        val sp = ctx.getSharedPreferences("wx", Context.MODE_PRIVATE)
        val raw = sp.getString("json", null) ?: return null
        return try {
            val o = JSONObject(raw)
            val cur = o.getJSONObject("current")
            val code = cur.getInt("weather_code")
            val day = cur.getInt("is_day") == 1
            val curTime = cur.getString("time")
            val h = o.getJSONObject("hourly")
            val times = h.getJSONArray("time")
            val temps = h.getJSONArray("temperature_2m")
            val codes = h.getJSONArray("weather_code")
            val days = h.getJSONArray("is_day")
            val d = o.getJSONObject("daily")
            val hours = ArrayList<Hour>()
            for (i in 0 until times.length()) {
                val t = times.getString(i)
                if (t > curTime && hours.size < 5) {
                    hours.add(
                        Hour(
                            t.substring(11, 16),
                            emoji(codes.getInt(i), days.getInt(i) == 1),
                            temps.getDouble(i).roundToInt()
                        )
                    )
                }
            }
            Snap(
                name = sp.getString("name", "Mi ubicación") ?: "Mi ubicación",
                temp = cur.getDouble("temperature_2m").roundToInt(),
                emoji = emoji(code, day),
                text = text(code),
                max = d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                min = d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                hours = hours
            )
        } catch (e: Exception) {
            null
        }
    }

    fun renderAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val snap = load(ctx)
        val ts = ctx.getSharedPreferences("wx", Context.MODE_PRIVATE).getLong("ts", 0L)
        val updated = if (ts > 0) SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts)) else ""
        for (cls in classes) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isEmpty()) continue
            val rv = if (cls == MiniWidget::class.java) miniViews(ctx, snap, updated)
            else forecastViews(ctx, snap, updated)
            wireClicks(ctx, rv, cls)
            mgr.updateAppWidget(ids, rv)
        }
    }

    private fun miniViews(ctx: Context, s: Snap?, updated: String): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_mini)
        if (s == null) {
            rv.setTextViewText(R.id.w_city, "DATCO Clima")
            rv.setTextViewText(R.id.w_temp, "--°")
            rv.setTextViewText(R.id.w_emoji, "⛅")
            rv.setTextViewText(R.id.w_text, "Abrí la app")
            rv.setTextViewText(R.id.w_hilo, "para configurar")
        } else {
            rv.setTextViewText(R.id.w_city, s.name)
            rv.setTextViewText(R.id.w_temp, "${s.temp}°")
            rv.setTextViewText(R.id.w_emoji, s.emoji)
            rv.setTextViewText(R.id.w_text, s.text)
            rv.setTextViewText(R.id.w_hilo, "Máx ${s.max}° · Mín ${s.min}°" + if (updated.isNotEmpty()) "  ·  $updated" else "")
        }
        return rv
    }

    private fun forecastViews(ctx: Context, s: Snap?, updated: String): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_forecast)
        val ids = intArrayOf(R.id.h1, R.id.h2, R.id.h3, R.id.h4, R.id.h5)
        if (s == null) {
            rv.setTextViewText(R.id.w_city, "DATCO Clima")
            rv.setTextViewText(R.id.w_temp, "--°")
            rv.setTextViewText(R.id.w_emoji, "⛅")
            rv.setTextViewText(R.id.w_text, "Abrí la app para configurar")
            rv.setTextViewText(R.id.w_hilo, "")
            for (id in ids) rv.setTextViewText(id, "")
        } else {
            rv.setTextViewText(R.id.w_city, s.name)
            rv.setTextViewText(R.id.w_temp, "${s.temp}°")
            rv.setTextViewText(R.id.w_emoji, s.emoji)
            rv.setTextViewText(R.id.w_text, s.text)
            rv.setTextViewText(R.id.w_hilo, "Máx ${s.max}° · Mín ${s.min}°" + if (updated.isNotEmpty()) "  ·  $updated" else "")
            for (i in ids.indices) {
                val h = s.hours.getOrNull(i)
                rv.setTextViewText(ids[i], if (h == null) "" else "${h.label}\n${h.emoji}\n${h.temp}°")
            }
        }
        return rv
    }

    private fun wireClicks(ctx: Context, rv: RemoteViews, cls: Class<*>) {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), flags)
        rv.setOnClickPendingIntent(R.id.root, open)
        val refreshIntent = Intent(ctx, cls).setAction(ACTION_REFRESH)
        val refresh = PendingIntent.getBroadcast(ctx, 1, refreshIntent, flags)
        rv.setOnClickPendingIntent(R.id.w_refresh, refresh)
    }
}
